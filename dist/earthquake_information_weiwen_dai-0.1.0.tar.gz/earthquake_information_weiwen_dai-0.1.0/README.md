# earthquake_information_weiwen_dai

 The 'get_earthquake_info' is a python package that can query global earthquake information by date and location and visualize the information at the same time.

## Installation

```bash
$ pip install earthquake_information_weiwen_dai
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`earthquake_information_weiwen_dai` was created by Weiwen Dai. It is licensed under the terms of the MIT license.

## Credits

`earthquake_information_weiwen_dai` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
